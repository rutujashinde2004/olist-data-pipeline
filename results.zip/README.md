# Olist E-Commerce Data Pipeline & Customer Analytics

End-to-end data engineering and analytics project on the Brazilian Olist e-commerce dataset (~100K orders, 9 relational tables).

## Problem Statement
Olist's data lives in 9 raw CSV files. The goal is to build a clean, queryable database and answer business questions about revenue, seller performance, delivery impact on reviews, customer retention, and customer segments.

## Architecture
```
Kaggle CSVs -> Python (Pandas: clean, validate, derive) -> SQLite/PostgreSQL
            -> Advanced SQL analytics -> RFM + KMeans segmentation -> Charts
```

## Tech Stack
Python (Pandas, SQLAlchemy/sqlite3, scikit-learn, matplotlib), SQL (CTEs, window functions), SQLite/PostgreSQL, [AWS S3 / BigQuery]

## Project Structure
```
generate_sample_data.py # Synthetic data with the Olist schema (for instant demo)
etl_pipeline.py         # Extract, transform, load + indexes
analysis_queries.sql    # 8 advanced SQL queries
run_queries.py          # Executes queries, saves results, index speed-up demo
rfm_segmentation.py     # RFM scoring + KMeans clustering
data/raw/               # Olist CSVs (not committed)
results/                # Query outputs (CSV)
```

## ETL Highlights
- Deduplicated records, parsed dates, handled missing delivery dates
- Translated product categories from Portuguese to English
- Derived `delivery_days` and `is_late`
- Kept one review per order; collapsed geolocation to one row per zip prefix
- Created indexes on join keys

## SQL Analysis (analysis_queries.sql)
| # | Question | Concepts |
|---|---|---|
| 1 | Monthly revenue, running total, MoM growth | CTE, SUM OVER, LAG |
| 2 | Top 3 products per category | RANK, PARTITION BY |
| 3 | Cohort retention | Multi-CTE, FIRST_VALUE |
| 4 | Seller ranking | Conditional aggregation, RANK |
| 5 | Repeat vs one-time customers | Window over aggregate |
| 6 | Late delivery vs review score | Joins, derived flags |
| 7 | State revenue quartiles | NTILE |
| 8 | Index optimization | EXPLAIN QUERY PLAN |

## Key Insights
> Fill these from YOUR run on the real Olist data (results/ folder + printed RFM table).
- Late deliveries lower average review score from **X.X** to **X.X** (Q6)
- Top states (SP, RJ, MG) contribute **X%** of revenue (Q7)
- **X%** of customers never make a second purchase (Q5)
- "Champions" are **X%** of customers but generate **X%** of revenue (RFM)
- Adding an index on `order_items(seller_id)` cut query time by **X%** (Q8)

## How to Run
```bash
pip install -r requirements.txt

# Option A: instant demo with synthetic sample data (works offline, same schema as Olist)
python generate_sample_data.py

# Option B (use this for your resume): real data
#   Download "Brazilian E-Commerce Public Dataset by Olist" from Kaggle and
#   copy the 9 CSVs into data/raw/ (same file names, overwrite the samples)

python etl_pipeline.py        # Extract -> Transform -> Load into olist.db
python run_queries.py         # Runs all 8 SQL queries, saves results/*.csv, index demo
python rfm_segmentation.py    # RFM + KMeans, saves rfm_segments.png
```
You can also open `olist.db` in DB Browser for SQLite and run `analysis_queries.sql` manually.

## Cloud Component
[Describe what you did: e.g., uploaded cleaned CSVs to an S3 bucket / loaded tables into BigQuery sandbox and ran queries 1, 3 and 7.]

## Screenshots
![RFM Segments](rfm_segments.png)
